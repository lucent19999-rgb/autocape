package com.example.autocape.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerModelPart;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AutoElytraCapeClient implements ClientModInitializer {

    private boolean lastElytraState = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(MinecraftClient client) {
        if (client.player == null || client.options == null) {
            return;
        }

        ItemStack chestItem = client.player.getEquippedStack(EquipmentSlot.CHEST);
        boolean hasElytra = chestItem.isOf(Items.ELYTRA);

        if (hasElytra != lastElytraState) {
            lastElytraState = hasElytra;
            updateCapeSetting(client, hasElytra);
        }
    }

    private void updateCapeSetting(MinecraftClient client, boolean enableCape) {
        boolean isCurrentlyEnabled = client.options.isPlayerModelPartEnabled(PlayerModelPart.CAPE);

        if (isCurrentlyEnabled != enableCape) {
            client.options.togglePlayerModelPart(PlayerModelPart.CAPE, enableCape);
            client.options.sendClientSettings();
        }
    }
}
